package com.example.pracenjetroskova

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class MainActivity : AppCompatActivity() {
    private lateinit var deletedTransaction: Transakcija
    private lateinit var transakcija : List<Transakcija>
    private lateinit var oldTransakcija : List<Transakcija>
    private lateinit var tranakcijskiAdapter: TranakcijskiAdapter
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var db : AppDatabase


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        transakcija = arrayListOf()

        tranakcijskiAdapter = TranakcijskiAdapter(transakcija)

        db = Room.databaseBuilder(this,
            AppDatabase::class.java,
            "transakcije").build()

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.adapter = tranakcijskiAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)


        val addBtn = findViewById<FloatingActionButton>(R.id.addBtn)

        //swipe to delete
        val itemTouchHelper = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                deleteTransaction(transakcija[viewHolder.adapterPosition])
            }

        }

        val swipteHelper = ItemTouchHelper(itemTouchHelper)
        swipteHelper.attachToRecyclerView(recyclerView)


        addBtn.setOnClickListener {
            val intent = Intent(this, AddTransactionActivity::class.java)
            startActivity(intent)
        }
    }


    private fun fetchAll(){
        GlobalScope.launch {
            transakcija = db.transactionDao().getAll()

            runOnUiThread {
                updateDashboard()
                tranakcijskiAdapter.setData(transakcija)
            }
        }
    }

    private fun updateDashboard() {
        val totalAmount = transakcija.map { it.amount }.sum()
        val budgetAmount = transakcija.filter { it.amount > 0 }.map { it.amount }.sum()
        val expenseAmount = totalAmount - budgetAmount

        val balanceTextView = findViewById<TextView>(R.id.balance)
        balanceTextView.text = "€ %.2f".format(totalAmount)

        val budgetTextView = findViewById<TextView>(R.id.budget)
        budgetTextView.text = "€ %.2f".format(budgetAmount)

        val trosakTextView = findViewById<TextView>(R.id.trosak)
        trosakTextView.text = "€ %.2f".format(expenseAmount)
    }

    private fun undoDelete(){
        GlobalScope.launch {
            db.transactionDao().insertAll(deletedTransaction)

            transakcija = oldTransakcija

            runOnUiThread {
                tranakcijskiAdapter.setData(transakcija)
                updateDashboard()
            }
        }
    }

    private fun showSnackbar(){
        val view = findViewById<View>(R.id.coordinator)
        val snackbar = Snackbar.make(view, "Transakcija obisana", Snackbar.LENGTH_LONG)
        snackbar.setAction("Vrati"){
            undoDelete()
        }
            .setActionTextColor(ContextCompat.getColor(this, R.color.crvena))
            .setTextColor(ContextCompat.getColor(this, R.color.white))
            .show()
    }

    private fun deleteTransaction(transakcije : Transakcija){
        deletedTransaction = transakcije
        oldTransakcija = transakcija

        GlobalScope.launch {
            db.transactionDao().delete(transakcije)

            transakcija = transakcija.filter {it.id != transakcije.id}
            runOnUiThread {
                updateDashboard()
                tranakcijskiAdapter.setData(transakcija)
                showSnackbar()
            }
        }

    }




    override fun onResume() {
        super.onResume()
        fetchAll()
    }
}