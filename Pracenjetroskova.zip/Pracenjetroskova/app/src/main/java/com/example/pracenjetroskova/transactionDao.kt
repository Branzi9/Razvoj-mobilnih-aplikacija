package com.example.pracenjetroskova

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao

interface transactionDao {
    @Query("SELECT * from transactions")
    fun getAll(): List<Transakcija>

    @Insert
    fun insertAll(vararg transakcija: Transakcija)

    @Delete
    fun delete(transakcija: Transakcija)

    @Update
    fun update(vararg transakcija: Transakcija)
}