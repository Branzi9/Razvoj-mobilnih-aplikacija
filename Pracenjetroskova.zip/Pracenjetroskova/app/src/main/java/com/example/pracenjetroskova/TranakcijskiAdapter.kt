package com.example.pracenjetroskova

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class TranakcijskiAdapter(private var transakcija: List<Transakcija>) :
    RecyclerView.Adapter<TranakcijskiAdapter.TransakcijskiDržač>() {

    class TransakcijskiDržač(view: View) : RecyclerView.ViewHolder(view) {
        val label : TextView = view.findViewById(R.id.label)
        val amount : TextView = view.findViewById(R.id.amount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransakcijskiDržač {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.transakcija_layout, parent, false)
        return TransakcijskiDržač(view)
    }

    override fun onBindViewHolder(holder: TransakcijskiDržač, position: Int) {
        val transakcija = transakcija[position]
        val context = holder.amount.context

        if (transakcija.amount >= 0) {
            holder.amount.text = "+ %.2f €".format(transakcija.amount)
            holder.amount.setTextColor(ContextCompat.getColor(context, R.color.zelena))
        } else {
            holder.amount.text = "- %.2f €".format(Math.abs(transakcija.amount))
            holder.amount.setTextColor(ContextCompat.getColor(context, R.color.crvena))
        }

        holder.label.text = transakcija.label

        holder.itemView.setOnClickListener {
            val intent = Intent(context, DetailedActivity::class.java)
            intent.putExtra("transaction", transakcija)
            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return transakcija.size
    }

    fun setData(transakcija: List<Transakcija>){
        this.transakcija = transakcija
        notifyDataSetChanged()
    }

}