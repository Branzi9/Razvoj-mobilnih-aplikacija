package com.example.pracenjetroskova

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.widget.AppCompatButton
import androidx.room.Room
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class AddTransactionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_transaction)


        val addTransactionBtn = findViewById<AppCompatButton>(R.id.addTransactionBtn)


        addTransactionBtn.setOnClickListener {
            val labelInput = findViewById<TextInputEditText>(R.id.labelInput)
            val labelLayout = findViewById<TextInputLayout>(R.id.labelLayout)
            val descriptionInput = findViewById<TextInputEditText>(R.id.descriptionInput)
            val amountInput = findViewById<TextInputEditText>(R.id.AmountInput)
            val amountLayout = findViewById<TextInputLayout>(R.id.AmountLayout)

            val label = labelInput.text.toString()
            val description = descriptionInput.text.toString()
            val amountString = amountInput.text.toString()


            if (label.isEmpty()) {
                labelLayout.error = "Molim vas unesite ispravnu oznaku."
            }

            if (amountString.isEmpty()) {
                amountLayout.error = "Molim vas unesite iznos."
            } else {
                val amount = amountString.toDoubleOrNull()

                if (amount == null) {
                    amountLayout.error = "Molim vas unesite točan iznos."
                } else {
                    if (description.isEmpty()) {
                        labelInput.error = "Molimo vas unesite opis transakcije."
                    } else {
                        val transakcija = Transakcija(0, label, amount, description)
                        insert(transakcija)
                    }
                }
            }
        }

        val closeBtn = findViewById<ImageButton>(R.id.closeBtn)

        closeBtn.setOnClickListener {
            finish()
        }
    }
    private fun insert(transakcija: Transakcija){
        val db = Room.databaseBuilder(this,
            AppDatabase::class.java,
            "transakcije").build()

        GlobalScope.launch {
            db.transactionDao().insertAll(transakcija)
            finish()
        }
    }
}


